package ch.zli.m223.punchclock.repository;

import ch.zli.m223.punchclock.domain.Entry;
import ch.zli.m223.punchclock.domain.Roles;
import org.springframework.data.jpa.repository.JpaRepository;
/**
 * Roles Repository
 *
 * @author Emanuel Constanti
 * @version 1.0
 */
public interface RolesRepository extends JpaRepository<Roles, Long> {
}
