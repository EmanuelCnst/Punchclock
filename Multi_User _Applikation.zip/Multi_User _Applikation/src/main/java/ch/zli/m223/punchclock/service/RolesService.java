package ch.zli.m223.punchclock.service;


import ch.zli.m223.punchclock.domain.Entry;
import ch.zli.m223.punchclock.domain.Roles;
import ch.zli.m223.punchclock.repository.EntryRepository;
import ch.zli.m223.punchclock.repository.RolesRepository;
import org.springframework.stereotype.Service;


import java.util.List;

@Service
public class RolesService {

    private RolesRepository rolesRepository;

    public RolesService(RolesRepository rolesRepository) {
        this.rolesRepository = rolesRepository;
    }

    public Roles createRoles(Roles roles) {
        return rolesRepository.saveAndFlush(roles);
    }

    public List<Roles> findAll() {
        return rolesRepository.findAll();
    }

    public void deleteRoles(Long id) { rolesRepository.deleteById(id); }

    public Roles updateRoles(Roles roles) {
        return rolesRepository.save(roles);
    }

}
