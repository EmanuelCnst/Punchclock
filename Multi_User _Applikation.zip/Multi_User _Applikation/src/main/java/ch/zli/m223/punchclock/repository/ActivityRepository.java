package ch.zli.m223.punchclock.repository;

import ch.zli.m223.punchclock.controller.ActivityController;
import ch.zli.m223.punchclock.domain.Activity;
import org.springframework.data.jpa.repository.JpaRepository;
/**
 * Activity Repository
 *
 * @author Emanuel Constanti
 * @version 1.0
 */
public interface ActivityRepository extends JpaRepository<Activity, Long> {
}
