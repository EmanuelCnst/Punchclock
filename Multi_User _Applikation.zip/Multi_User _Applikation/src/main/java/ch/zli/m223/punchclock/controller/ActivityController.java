package ch.zli.m223.punchclock.controller;

import ch.zli.m223.punchclock.domain.Activity;
import ch.zli.m223.punchclock.domain.Roles;
import ch.zli.m223.punchclock.service.ActivityRolesService;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;
/**
 * Activity Controller
 *
 * @author Emanuel Constanti
 * @version 1.0
 */
@RestController
@RequestMapping("/activity")
public class ActivityController {

    private ActivityRolesService activityRolesService;

    public ActivityController(ActivityRolesService activityRolesService) {
        this.activityRolesService = activityRolesService;
    }

    @GetMapping
    @ResponseStatus(HttpStatus.OK)
    public List<Activity> getAllActivity() {
        return activityRolesService.findAll();
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public Activity createActivity(@Valid @RequestBody Activity activity) {
        return activityRolesService.createActivity(activity);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void deleteActivity(@PathVariable Long id) {
        activityRolesService.deleteActivity(id);
    }

    @PutMapping("/{id}")
    @ResponseStatus(HttpStatus.OK)
    public Activity updateActivity(@Valid @RequestBody Activity activity) {
        return activityRolesService.updateActivity(activity);
    }

}

