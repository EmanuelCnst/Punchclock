package ch.zli.m223.punchclock.controller;



import ch.zli.m223.punchclock.domain.Roles;
import ch.zli.m223.punchclock.service.RolesService;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;
/**
 * Roles Controller
 *
 * @author Emanuel Constanti
 * @version 1.0
 */
@RestController
@RequestMapping("/roles")
public class RolesController {

    private RolesService rolesService;

    public RolesController(RolesService rolesService) {
        this.rolesService = rolesService;
    }

    /**
     *Zeigt eine Liste aller Rollen an
     * @return
     */
    @GetMapping
    @ResponseStatus(HttpStatus.OK)
    public List<Roles> getAllRoles() {
        return rolesService.findAll();
    }

    /**
     * Kreiert eine neue Rolle
     * @param roles
     * @return
     */
    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public Roles createRoles(@Valid @RequestBody Roles roles) {
        return rolesService.createRoles(roles);
    }

    /**
     * Löscht Rollen
     * @param id
     */
    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void deleteRoles(@PathVariable Long id) {
        rolesService.deleteRoles(id);
    }

    @PutMapping("/{id}")
    @ResponseStatus(HttpStatus.OK)
    public Roles updateRoles(@Valid @RequestBody Roles roles) {
        return rolesService.updateRoles(roles);
    }

}
