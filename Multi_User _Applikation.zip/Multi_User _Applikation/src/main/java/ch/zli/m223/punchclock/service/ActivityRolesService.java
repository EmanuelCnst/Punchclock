package ch.zli.m223.punchclock.service;

import ch.zli.m223.punchclock.controller.ActivityController;
import ch.zli.m223.punchclock.domain.Activity;
import ch.zli.m223.punchclock.repository.ActivityRepository;
import org.springframework.stereotype.Service;

import java.util.List;


@Service
public class ActivityRolesService {

    private ActivityRepository activityRepository;

    public ActivityRolesService(ActivityRepository activityRepository) {
        this.activityRepository = activityRepository;
    }

    public Activity createActivity(Activity activity) {
        return activityRepository.saveAndFlush(activity);
    }

    public List<Activity> findAll() {
        return activityRepository.findAll();
    }

    public void deleteActivity(Long id) { activityRepository.deleteById(id); }

    public Activity updateActivity(Activity activity) {
        return activityRepository.save(activity);
    }


}
