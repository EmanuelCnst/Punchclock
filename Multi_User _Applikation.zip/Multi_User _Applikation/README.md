# M223: Punchclock 
Dies ist eine Appikation für ein Multiusersystem 

## Was die Applikation tut
Mit der folgenden Applikation kann man Benutzer Registierern und Anmelden.
Desweitern kann man in der Applikation Zeiteinträge löschen,bearbeiten und löschen mann muss aber Adminstrator Rechte dazu haben.




## Loslegen
Folgende Schritte befolgen um loszulegen:
1. Sicherstellen, dass JDK 11 installiert und in der Umgebungsvariable `path` definiert ist.
1. Ins Verzeichnis der Applikation wechseln und über die Kommandozeile mit `./gradlew bootRun` oder `./gradlew.bat bootRun` starten
1. Unittest mit `./gradlew test` oder `./gradlew.bat test` ausführen.
1. Ein ausführbares JAR kann mit `./gradlew bootJar` oder `./gradlew.bat bootJar` erstellt werden.

Folgende Dienste stehen während der Ausführung im Profil `dev` zur Verfügung:
- REST-Schnittstelle der Applikation: http://localhost:8081
- Dashboard der H2 Datenbank: http://localhost:8081/h2-console
# Punchchcklock_
